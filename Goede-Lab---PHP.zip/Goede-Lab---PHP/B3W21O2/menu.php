<?php 
	echo "<a href='../Labs/lab-2.php'>Lab 2</a>
	<a href='../Labs/lab-3a.php'>Lab 3a</a>
	<a href='../Labs/lab-3b.php'>Lab 3b</a>
	<a href='../Labs/lab-4.php'>Lab 4</a>
	<a href='../B3W21O1/B3W21O1.php'>B3W21O1</a>"
?>